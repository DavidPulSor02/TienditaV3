package com.example.tienditav3;

import android.os.Bundle;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import java.util.ArrayList;
import java.util.List;

public class CarritoActivity extends AppCompatActivity {

    private LinearLayout cartItemsLayout;
    private TextView cartTotalText;
    private Button payButton;

    // Lista que simula los productos en el carrito
    private List<Product> cart = new ArrayList<>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_carrito);

        cartItemsLayout = findViewById(R.id.cartItemsLayout);
        cartTotalText = findViewById(R.id.cartTotalText);
        payButton = findViewById(R.id.payButton);

        // Simular algunos productos en el carrito
        cart.add(new Product("Cocacola", 20.0));
        cart.add(new Product("Monster", 25.0));

        displayCartItems();
        updateCartTotal();

        // Evento para el botón de pagar
        payButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (cart.isEmpty()) {
                    Toast.makeText(CarritoActivity.this, "El carrito está vacío", Toast.LENGTH_SHORT).show();
                } else {
                    Toast.makeText(CarritoActivity.this, "Procesando pago...", Toast.LENGTH_SHORT).show();
                    cart.clear(); // Vaciar el carrito después de la simulación de pago
                    displayCartItems();
                    updateCartTotal();
                }
            }
        });
    }

    private void displayCartItems() {
        cartItemsLayout.removeAllViews(); // Limpiar el layout antes de mostrar los items

        for (Product product : cart) {
            LinearLayout itemLayout = new LinearLayout(this);
            itemLayout.setOrientation(LinearLayout.HORIZONTAL);
            itemLayout.setLayoutParams(new LinearLayout.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT,
                    ViewGroup.LayoutParams.WRAP_CONTENT));
            itemLayout.setPadding(0, 10, 0, 10);

            TextView itemName = new TextView(this);
            itemName.setText(product.getName());
            itemName.setTextSize(16);
            itemName.setLayoutParams(new LinearLayout.LayoutParams(
                    0, ViewGroup.LayoutParams.WRAP_CONTENT, 1));
            itemLayout.addView(itemName);

            TextView itemPrice = new TextView(this);
            itemPrice.setText("$" + product.getPrice());
            itemPrice.setTextSize(16);
            itemLayout.addView(itemPrice);

            Button removeButton = new Button(this);
            removeButton.setText("Eliminar");
            removeButton.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    cart.remove(product);
                    displayCartItems();
                    updateCartTotal();
                    Toast.makeText(CarritoActivity.this, product.getName() + " eliminado del carrito", Toast.LENGTH_SHORT).show();
                }
            });
            itemLayout.addView(removeButton);

            cartItemsLayout.addView(itemLayout);
        }
    }

    private void updateCartTotal() {
        double total = 0;
        for (Product product : cart) {
            total += product.getPrice();
        }
        cartTotalText.setText("Total: $" + total);
    }

    // Clase interna para productos
    private static class Product {
        private final String name;
        private final double price;

        public Product(String name, double price) {
            this.name = name;
            this.price = price;
        }

        public String getName() {
            return name;
        }

        public double getPrice() {
            return price;
        }
    }
}
